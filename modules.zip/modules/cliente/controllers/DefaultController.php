<?php

namespace app\modules\cliente\controllers;

use yii\web\Controller;
use app\modules\cliente\models\Clientes;

/**
 * Default controller for the `ClienteModule` module
 */
class DefaultController extends Controller
{
    /**
     * Renders the index view for the module
     * @return string
     */
    public function actionIndex()
    {
        $clientes = [
            ['nome'=>'A'],
            ['nome'=>'B'],
            ['nome'=>'C'],
            ['nome'=>'D'],            
        ];
        /*foreach($clientes as $cliente){
            $row = new Clientes;
            $row->nome = $cliente['nome'];
            $row->save();
        }*/

        //\Yii::app->createCommand('del')
            
        /*$condition = ['=', 'nome', 'C'];
        $command = \Yii::$app->db->createCommand()->delete('clientes', $condition);
        $command->execute();*/
       
        $command = \Yii::$app
            ->db
            ->createCommand()
            ->batchInsert(Clientes::tableName(),['nome'],$clientes)
            ->execute();
        echo "ok";
          
    }

    public function actionCreate()
    {

    }
}

