<?php

namespace app\modules\webhook\controllers;

use yii\web\Controller;
use yii\web\Response;
/**
 * Default controller for the `WebhookModules` module
 */
class DefaultController extends Controller
{
    /**
     * Renders the index view for the module
     * @return string
     */
    public function actionIndex()
    {
       
    $webhookData = \Yii::$app->request->getRawBody();

        \Yii::$app->response->format = Response::FORMAT_JSON;
        return ['status' => 'success'];
    }


}
