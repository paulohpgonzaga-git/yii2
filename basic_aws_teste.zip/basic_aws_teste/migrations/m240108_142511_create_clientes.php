<?php

use yii\db\Migration;

/**
 * Class m240108_142511_create_clientes
 */
class m240108_142511_create_clientes extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function up()
    {
        $this->createTable('{{%clientes}}',[
            'id' => $this->primaryKey(),
            'nome' => $this->string(60)->notNull()
        ]);


    }

    /**
     * {@inheritdoc}
     */
    public function down()
    {       
        $this->dropTable('{{%clientes}}');   
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m240108_142511_create_clientes cannot be reverted.\n";

        return false;
    }
    */
}
