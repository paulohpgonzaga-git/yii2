<?php

use yii\db\Migration;

/**
 * Class m240109_124014_create_events
 */
class m240109_124014_create_events extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function up()
    {
        $this->createTable('{{events}}',[
            'id' => $this->primaryKey(),
            'desc' => $this->text(65000)->notNull()
        ]);


    }

    /**
     * {@inheritdoc}
     */
    public function down()
    {
        $this->dropTable('{{events}}');   
    }

}
